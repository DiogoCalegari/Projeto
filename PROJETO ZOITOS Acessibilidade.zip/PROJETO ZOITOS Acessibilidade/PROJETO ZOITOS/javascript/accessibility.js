const root = document.documentElement;
const body = document.body;

const toggleContrastBtn = document.getElementById("toggle-contrast");

const increaseFontBtn = document.getElementById("increase-font");
const decreaseFontBtn = document.getElementById("decrease-font");

toggleContrastBtn.addEventListener("click", () => {
  body.classList.toggle("high-contrast");
  if (body.classList.contains("high-contrast")) {
    localStorage.setItem("theme", "high-contrast");
    toggleContrastBtn.setAttribute("aria-pressed", "true");
  } else {
    localStorage.removeItem("theme");
    toggleContrastBtn.setAttribute("aria-pressed", "false");
  }
});

let currentFontSize = parseFloat(localStorage.getItem("font-size")) || 100;
const FONT_STEP = 10;
const FONT_MAX = 200;
const FONT_MIN = 80;

function updateFontSize() {
  root.style.setProperty("--base-font-size", `${currentFontSize}%`);
  localStorage.setItem("font-size", currentFontSize);
}

increaseFontBtn?.addEventListener("click", () => {
  if (currentFontSize < FONT_MAX) {
    currentFontSize += FONT_STEP;
    updateFontSize();
  }
});

decreaseFontBtn?.addEventListener("click", () => {
  if (currentFontSize > FONT_MIN) {
    currentFontSize -= FONT_STEP;
    updateFontSize();
  }
});

window.addEventListener("load", () => {
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "high-contrast") {
    body.classList.add(savedTheme);
    toggleContrastBtn?.setAttribute("aria-pressed", "true");
  }

  updateFontSize();
});
