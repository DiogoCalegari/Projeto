document.addEventListener("DOMContentLoaded", carregarLista);

document.getElementById("Cadastrar").onclick = cadastrarUsuario;
document.getElementById("Limpar").onclick = limparCampos;
document.getElementById("ExcluirTudo").onclick = excluirTudo;
document.getElementById("pesquisa").oninput = pesquisar;

console.log("ADMIN.JS CARREGADO");

function cadastrarUsuario() {
  const nome = document.getElementById("nome").value.trim();
  const email = document.getElementById("email").value.trim();

  if (!nome || !email) {
    alert("Preencha todos os campos!");
    return;
  }

  const data = new Date().toLocaleString("pt-BR");

  const novoUsuario = { nome, email, data };

  let lista = JSON.parse(localStorage.getItem("usuarios")) || [];

  lista.push(novoUsuario);

  localStorage.setItem("usuarios", JSON.stringify(lista));

  carregarLista();

  limparCampos();
}

function carregarLista(filtro = "") {
  const ul = document.getElementById("listaUsuarios");
  ul.innerHTML = "";

  let lista = JSON.parse(localStorage.getItem("usuarios")) || [];

  lista = lista.filter(
    (item) =>
      item.nome.toLowerCase().includes(filtro.toLowerCase()) ||
      item.email.toLowerCase().includes(filtro.toLowerCase())
  );

  lista.forEach((usuario, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <strong>${usuario.nome}</strong> - ${usuario.email} <br>
      <small>${usuario.data}</small>
      <button onclick="excluirItem(${index})">Excluir</button>
    `;
    ul.appendChild(li);
  });
}

function limparCampos() {
  document.getElementById("nome").value = "";
  document.getElementById("email").value = "";
}

function excluirItem(index) {
  let lista = JSON.parse(localStorage.getItem("usuarios")) || [];
  lista.splice(index, 1);
  localStorage.setItem("usuarios", JSON.stringify(lista));
  carregarLista();
}

function excluirTudo() {
  localStorage.removeItem("usuarios");
  carregarLista();
}

function pesquisar() {
  const texto = document.getElementById("pesquisa").value;
  carregarLista(texto);
}
