document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("admbotao").onclick = function () {
    window.location.href = "admin.html";
  };
});
